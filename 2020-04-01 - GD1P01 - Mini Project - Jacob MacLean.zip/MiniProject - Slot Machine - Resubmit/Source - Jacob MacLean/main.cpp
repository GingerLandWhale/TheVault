#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;


int main()
{
reset:
	char letter = 'A';
	int credits = 2000;
	int integer = 0;
	int bet = 0;
	int prize = 0;
	int loss = 0;
	srand(time(NULL));

	int x = 1; x < 4; x++;

	cout << "                                                                                        .ohddh+` " << endl;
	cout << "                                                                                       `yNNNNNNs " << endl;
	cout << "          `..--------------------------------------------------------------------.'    `hNNNNNNy" << endl;
	cout << "        .+hmNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNmh+.   .odmmdo`     " << endl;
	cout << "      mNNNh`yNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNh`yNNNm` `dNNy       " << endl;
	cout << "      NNNNs.NNNNmo++++++++++++++++smNho++++++++++++++++yNNs++++++++++++++++odNNNN.oNNNN` `dNNy       " << endl;
	cout << "      NNNNo.NNNM:                  om`                  ms                  :NNNN.oNNNN.``dNNy``     " << endl;
	cout << "      NNNNo.NNNM:  .//.:oo/-``:/`  +m`  :/:./o+/.``/:   ds  `//--+o+:.`-/-  -NNNN.oNNNN:d/hNNy+y     " << endl;
	cout << "      NNNNo.NNNM-  oMNdNNNNNmdNm.  +d` `dNmmNNNNNmmNy`  do  -MNdNNNNNNdmN/  -NNNN.oNNNN:m/hNNy+N`    " << endl;
	cout << "      NNNNo.NNNM-  oMNmhhdmmmNN/   +m` `dNNdyhmmdNNd.   do  -MNNhhdmmmNNs`  -NNNN.oNNNN:m+yNNsoN`    " << endl;
	cout << "      NNNNo.NNNM-  oNN:   .smN+    +m` `dNd`  `:hNm.    do  .MNo   `+dNy`   -NNNN.oNNNN:mmssssmN     " << endl;
	cout << "      NNNNo.NNNM-  :oo` `+mNN+     +m` `+o/  .yNNm.     do  .oo-  :dNNy`    -NNNN.oNNNN:mNNNNNNN     " << endl;
	cout << "      NNNNo.NNNM-      .hNNNo      +m`      :mNNm:      do      `oNNNh`     -NNNN.oNNNN:NNNNNNNN     " << endl;
	cout << "      NNNNo.NNNM-     /NNNN+       +m`     yNNNm.       ds     .mNNNy       -NNNN.oNNNN:mNNNNNNm     " << endl;
	cout << "      NNNNo.NNNN-      ````        +m`     `````        mo      `````       -NNNN.oNNNN-+++++++-     " << endl;
	cout << "      NNNNo.NNNNo.````````````````.hN:`````````````````:Nh-`````````````````oNNNN.oNNNN`             " << endl;
	cout << "      NNNNs`mNNNNmmmmmmmmmmmmmmmmmmNNNmmmmmmmmmmmmmmmmmNNNmmmmmmmmmmmmmmmmmmNNNNN`oNNNN`             " << endl;
	cout << "       .odNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNds.               " << endl;
	cout << "          .:+syyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyys+:.                " << endl;


	cout << endl;
	cout << endl;
	cout << endl;
	cout << "                       Welcome to the SLOTS: Command Prompt Edition" << endl;
	cout << endl;
	cout << "                              How would you like to proceed?" << endl;
	cout << endl;
	cout << endl;
	cout << endl;
mainmenu:
	cout << "                                   1) Play the Slots" << endl;
	cout << "                                   2) See your money" << endl;
	cout << "                                   3) Credits" << endl;
	cout << "                                   4) Quit the Slots" << endl;


	cin >> integer;

	if (integer == 1)
	{
	FirstMenu:
		int randresult1 = 1 + (rand() % 7);
		int randresult2 = 1 + (rand() % 7);
		int randresult3 = 1 + (rand() % 7);
		cout << endl;
		cout << endl;
	bet:
		cout << "How much would you like to bet?";
		cout << endl;
		cin >> bet;
		if (bet > credits)
		{
			cout << "Sorry you do not have enough credits to make that bet." << endl;
			cout << "Please try again!" << endl;
			goto bet;
		}


		for (int x = 1; x < 2; x++)
		{
			cout << "_________________________" << endl;
			cout << "|       |       |       |" << endl;
			cout << "|   " << randresult1 << "   |   " << randresult2 << "   |   " << randresult3 << "   |" << endl;
			cout << "|_______|_______|_______|" << endl;
		}
		if (randresult1 == 7 && randresult2 == 7 && randresult3 == 7)
		{
			prize = bet * 10;
			credits = credits + prize;
			cout << "Bet: " << bet << endl;
			cout << "Prize: " << prize << endl;
			cout << "Total Money: " << credits << endl;
			;
		}
		else if (randresult1 == randresult2 == randresult3)
		{
			prize = bet * 5;
			credits = credits + prize;
			cout << "Bet: " << bet << endl;
			cout << "Prize: " << prize << endl;
			cout << "Total Money: " << credits << endl;
		}
		else if (randresult1 == randresult2 || randresult1 == randresult3 || randresult2 == randresult3)
		{
			prize = bet * 3;
			credits = credits + prize;
			cout << "Bet: " << bet << endl;
			cout << "Prize: " << prize << endl;
			cout << "Total Money: " << credits << endl;


		}
		else
		{
			loss = -bet;
			credits = credits - bet;
			cout << "Bet: " << bet << endl;
			cout << "Loss: " << loss << endl;
			cout << "Total Money: " << credits << endl;
		}

		if (credits == 0)
		{
			cout << "You have run out of Money" << endl;
			cout << "would you like to reset?" << endl;
			cout << "        Y | N" << endl;
			cin >> letter;

			if (letter == 'Y' || letter == 'y')
			{
				goto reset;
			}

			else if (letter == 'N' || letter == 'n')
			{
				cout << endl;
				cout << "Thank you for Playing" << endl;
				return(0);
			}

		}


		cout << "would you like to go back to play again?" << endl;
		cout << endl;
	input1:
		cout << "         [Y / N ]" << endl;
		cout << " [M to return to the menu]" << endl;
		cin >> letter;

		if (letter == 'Y' || letter == 'y')
		{
			goto FirstMenu;
		}

		else if (letter == 'N' || letter == 'n')
		{
			cout << "Thank you for Playing" << endl;
			return(0);
		}
		else if (letter == 'M' || letter == 'm')
		{
			cout << "returning to menu!" << endl;
			goto mainmenu;
		}
		else
		{
			cout << "That is not a valid character try again" << endl;
			goto input1;
		}
	}


	else if (integer == 2)
	{
		cout << "Credits: $" << credits << endl;
		cout << "Would you like to go back?" << endl;
	input2:
		cout << "       Y | N " << endl;
		cin >> letter;
		if (letter == 'Y' || letter == 'y')
		{
			goto mainmenu;
		}

		else if (letter == 'N' || letter == 'n')
		{
			cout << "Thank you for Playing" << endl;
			return(0);
		}
		else
		{
			cout << "That is not a valid character try again" << endl;
			goto input2;
		}

	}

	else if (integer == 3)
	{
		cout << "                               Credits:" << endl;
		cout << endl;
		cout << "                               Made by Jacob MacLean" << endl;
		cout << "                               Programmed by Jacob MacLean" << endl;
		cout << "                               Creavtive Driector: Jacob MacLean" << endl;
		cout << "                               Lead Artist: Jacob MacLean" << endl;
		cout << "                               Lead Animator : Jacob MacLean" << endl;
		cout << "                               Writing Team: Jacob MacLean" << endl;
		cout << "                               Janitor: Jacob MacLean" << endl;
		cout << "                               Catering: Jacob MacLean" << endl;
		cout << "                               Emotional Support: Dunstan, Jake and Ash" << endl;
		cout << endl;
		cout << endl;

		cout << "Would you like to return to the main menu?" << endl;
	input3:
		cout << "                Y | N " << endl;
		cin >> letter;
		if (letter == 'Y' || letter == 'y')
		{
			goto mainmenu;
		}

		else if (letter == 'N' || letter == 'n')
		{
			cout << "Thank you for Playing" << endl;
			return(0);
		}

		else
		{
			cout << "That is not a valid character try again" << endl;
			goto input3;
		}


	}
	else if (integer == 4)
	{
		cout << "Thanks for playing!" << endl;
		exit(0);
	}


	int iTemp;
	cin >> iTemp;
	return 0;
}

